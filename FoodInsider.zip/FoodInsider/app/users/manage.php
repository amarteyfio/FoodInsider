<?php

// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: app/users/login.php");
    exit;
}


require '../database/connection.php.';


?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Manage</title>
        <link rel="stylesheet" href="../../assets/css/style2.css">
        <link rel = 'stylesheet' href = '../../assets/css/style.css'>
    </head>

    <body>
    <header>
    <div class = "logo">
    <h1 class = 'logo-text'>FoodInsider</h1>
         
    </div>
    <ul class = "navbar">
        <li><a href = "index.php">Home</a></li>
        <li><a href = "index.php">Services</a></li>
        <li><a href = "index.php">About</a></li>
       <!--- <li><a href = "#">Sign Up</a></li>
        <li><a href = "#">Log in</a></li> --->
        <li>
            <a href = "#"><i class="far fa-user"></i><?php echo htmlspecialchars($_SESSION["username"]); ?></a>
            <ul>
                <li><a href = "manage.php">Profile</a></li>
                <li><a href = "logout.php" class = logout_bttn  >Logout</a></li>
                
            </ul>
        </li>       
    </ul>
</header>
        <h1 class="page-title">Manage</h1>
        <div class= "content">
           <table>
                <thead>
                    <th>Book ID</th>
                    <th>Title</th>
                    <th>Author</th>
                </thead>

                <tbody>
                    <?php
                        $articles= array();
                         //write query
                         $user = $_SESSION['id'];
                        

                         $sql = "SELECT * FROM posts WHERE user_id = '$user'";
                         $result = mysqli_query($db, $sql);
                         
                        
                        while($row = mysqli_fetch_assoc($result)) 
                        {$articles[] = $row;
                        }
                        foreach ($articles as $row)
                        :
                    ?>

                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['title']; ?></td>
                            <td><?php echo $row['Author']; ?></td>
                        </tr>
                    <?php endforeach;?>
                    
                </tbody>
            </table>

            <br>
       
            <div class="editButton">
                <!--update button -->
                <form method=POST action="update.php">
                    <input type="submit" value="UPDATE" name="upArt" id="upbtn">
                </form>
                <br>
                  

                <!--create button -->
                <form method=POST action="Create.php">
                    <input type="submit" value="CREATE" name="upArt" id="upbtn">
                </form>  
            </div>
            
        </div>
        <br>
        <br>
        <br>

        
        <?php include ("../includes/footer.php"); ?>
    </body>
</html>