<?php require '../database/connection.php';


// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create</title>
    <link rel="stylesheet" href="../../assets/css/style2.css">
    <link rel = 'stylesheet' href = '../../assets/css/style.css'>
</head>
<body>
<header>
    <div class = "logo">
    <h1 class = 'logo-text'>FoodInsider</h1>
         
    </div>
    <ul class = "navbar">
        <li><a href = "index.php">Home</a></li>
        <li><a href = "index.php">Services</a></li>
        <li><a href = "index.php">About</a></li>
       <!--- <li><a href = "#">Sign Up</a></li>
        <li><a href = "#">Log in</a></li> --->
        <li>
            <a href = "#"><i class="far fa-user"></i><?php echo htmlspecialchars($_SESSION["username"]); ?></a>
            <ul>
                <li><a href = "manage.php">Profile</a></li>
                <li><a href = "logout.php" class = logout_bttn  >Logout</a></li>
                
            </ul>
        </li>       
    </ul>
</header>

<div class="content">
    <div class = "page-wrapper">
        <h1> Create </h1>

        <form  method="GET" action="" enctype="multipart/form-data">
            <!--title form-->
            <p> Title</p>

            <input type="text" name="articleTitle" class="text-input">

            <!--author form-->
            <p> Author</p>

            <input type="text" name="authorName" class="text-input"> 

            <!--userID form-->
            <!-- <p> User ID</p>

            <input type="text" name="userID" class="text-input">
 -->
        
            <!--Enter Article form-->
            <p>Write Article:</p>
            <textarea name="writeArticle" cols="100" rows="10"></textarea >
            <br>
            <br>

            <input type="submit" value="Add" name="addArticle">
        </form>

    </div> 

    <?php
        if(isset($_GET['addArticle'])){
            //path to store uploaded image 
            //$target = "webTechgrp/". basename($_FILES['artImage']);
        
            //write query 
            $articleTitle= $_GET['articleTitle'];
            $author= $_GET['authorName'];
            $articleBody= $_GET['writeArticle'];
            //$articleImage=$_FILES['artImage'];
            $id=$_SESSION['id'];
            $sql = "INSERT INTO posts (title,body,Author,user_id) 
            VALUES ('$articleTitle','$articleBody','$author','$id')";
            
            //execute query
            if (mysqli_query($db, $sql)) {
                echo "New record created successfully:";
                echo $articleTitle;
            } 
            else {
                echo "Error: " . $sql . "<br>" . mysqli_error($db);
            }

            /* //move uploaded image into folder
            if(move_uploaded_file($_FILES['artImage'], $target)){
                echo "Image uploaded successfully.";
            }
            else{
                echo "No mas for upload"; 
            } */
        }
    ?>
</div>    
    <?php include ("../includes/footer.php"); ?>
    
</body>
</html>