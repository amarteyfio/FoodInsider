<?php
require_once "../database/connection.php";



//ACTION FOR WHEN USER SUBMITS

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])){
    
    $fullname = trim($_POST['Fname']);
    $email = trim($_POST['email']);
    $username = trim($_POST['uname']);
    $password = trim($_POST['passw']);
    

    //Validate Email
    if($query = $db->prepare("SELECT * FROM users WHERE email = ? ")){
        $error ='';
        

        $query->bind_param('s',$email);
        $query->execute();
        
        $query->store_result();
        if ($query->num_rows > 0) {
            $error .= '<p class="error">The email address is already registered!</p>';
        } 

        // VAlidate Username
        elseif($query = $db->prepare("SELECT * FROM users WHERE username = ? ")){
            $error = '';
    
            $query->bind_param('s',$username);
            $query->execute();
            
            $query->store_result();
            if ($query->num_rows > 0) {
                $error .= '<p class="error">The username already exists!</p>';
            } 
        }
    }
    //Validate password
        else {
            if (strlen($password ) < 6) {
                $error .= '<p class = "error"> Password is too short!</p>';
            }

        }

        //Insert into DB
        if (empty($error)) {
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            $insertQuery = $db->prepare("INSERT INTO users (name,email,username,password) VALUES (?,?,?,?);");
            $insertQuery->bind_param("ssss",$fullname,$email,$username,$password_hash);
            
            $result = $insertQuery->execute();
            if ($result) {
                $error .= '<p class = "success"> Registration Successful</p>';

            }
            else{
                $error .= '<p class = "error"> Something went wrong!</p>';
            }
        }
    }    
       

    
       
        
        




?>




<!DOCTYPE html> 
<html>
 
	<head> 
		<meta charset= "UTF-8">
	        <meta http-equiv="X-UA-Compatible" content="IE=edge">
     		<meta name="viewport" content="width=device-width, initial-scale=1.0">
     		<link rel = "stylesheet" href="../../assets/css/signupstyle.css">
	</head>
    <body>
		<div class = "logo">
			<h1 class = 'logo-text'>FoodInsider</h1>
				 
			</div>
		
		 
		 <div class = "signup-form">
        <h1>Get Started</h1>
        <?php if(empty($error)){
            echo "";
        }else{
            echo $error;
        }
        ?>
        <br>
		<form action = "signup.php" method = "POST">
			<input type = 'text' name = 'Fname' placeholder = 'Name'>
			<br>
			<br>
			<input type = 'text' name = 'email' placeholder = 'E-mail'>
			<br>
			<br>
            <input type = 'text' name = 'uname' placeholder = 'Username'>
            <br>
            <br>
            <input type = 'password' name = 'passw' placeholder = 'Password'>
            <br>
            <br>
			<button type = 'submit' name="submit">Sign Up</button>
            <br>
            <br>
            <br>
            <p>Already have an account? <a href = 'login.php'>Log In Now</a> </p>
		</form>
		</div>
	</body>
	

</html>


