<?php require '../database/connection.php';

// Initialize the session
session_start();
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

//set session for first form
if(isset($_POST['editArticle2'])){
    $_SESSION['FirstSearch']= $_POST['bookID'];
}  

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
    <link rel="stylesheet" href="style2.css">
    <link rel = 'stylesheet' href = '../../assets/css/style.css'>
</head>

<body>
<header>
    <div class = "logo">
    <h1 class = 'logo-text'>FoodInsider</h1>
         
    </div>
    <ul class = "navbar">
        <li><a href = "index.php">Home</a></li>
        <li><a href = "index.php">Services</a></li>
        <li><a href = "index.php">About</a></li>
       <!--- <li><a href = "#">Sign Up</a></li>
        <li><a href = "#">Log in</a></li> --->
        <li>
            <a href = "#"><i class="far fa-user"></i><?php echo htmlspecialchars($_SESSION["username"]); ?></a>
            <ul>
                <li><a href = "manage.php">Profile</a></li>
                <li><a href = "logout.php" class = logout_bttn  >Logout</a></li>
                
            </ul>
        </li>       
    </ul>
</header>
    <!--manage body content-->
    <div class="content">
        <h1 class="page-title">Update</h1>
        <form method=POST action="">
            <!--get book ID-->
            <p> Book ID</p>
            <input type="text" name="bookID" class="text-input" value= "<?php echo
                
                (isset($_SESSION['FirstSearch'])) ? $_SESSION['FirstSearch'] : ' ' ;
                
                ?>"  
            >

            <input type="submit" value="Select" name="editArticle2" >
            <input type="submit" value="Delete" name="deleteArticle">
            
            <!--<button name="editArticle3" type="button" onclick="myFunction()">Try it</button>-->

        <br>

            <!--Enter Article form-->
            <p>Update Article:</p>
            <textarea id="myTextarea" name="updateArticle" cols="100" rows="10">
                <?php
                    if(isset($_POST['editArticle2'])){
                        $getartID= $_POST['bookID'];

                        //write query
                        $sql=  "SELECT * FROM posts WHERE id = '$getartID'";
                        $result = mysqli_query($db, $sql);

                        if (mysqli_num_rows($result) > 0) {
                                            
                            while($row = mysqli_fetch_assoc($result)) {
                                echo $row["body"];
                                
                            }
                        } 
                        else {
                            echo 'not found';
                        }
                    }
                ?>
            </textarea >

            <br>

            <input type="submit" value="Edit" name="updateButton">

        </form>

        <?php
            if(isset($_POST['updateButton'])){
                $getArtBody=$_POST['updateArticle'];
                $getartID= $_POST['bookID'];
                $updatesql = "UPDATE posts SET body='$getArtBody' WHERE id= '$getartID'";

                
                if ($db->query($updatesql) === TRUE) {
                    echo "Record updated successfully";
                    
                } 
                else {
                    echo "Error updating record: " . $db->error;
                }
            }
        ?>

        <?php
            if(isset($_POST['deleteArticle'])){
                $getartID= $_POST['bookID'];
                //write query
                $delsearchsql=  "SELECT * FROM posts WHERE id = '$getartID'";
                $delsql=  "DELETE FROM posts WHERE id= '$getartID'";
                $delsearchResult = mysqli_query($db, $delsearchsql);
                $delResult = mysqli_query($db, $delsql);

                if (mysqli_num_rows($delsearchResult) > 0) {
                    if ($delResult) {
                        echo "Record deleted successfully";
                    } 
                    else {
                        echo "Error deleting record: " . mysqli_error($db);
                    }
                }

                else{
                    echo "Not found.";
                }
            }
        ?>
    </div>

    <?php include ("../includes/footer.php"); ?>
    
</body>
</html>