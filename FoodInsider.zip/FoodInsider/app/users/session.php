<?php

//session start
session_start();

//check
if (isset($_SESSION["id"]) && $_SESSION["id"] === true){
    header("location: index.php");
    exit;
}

?>