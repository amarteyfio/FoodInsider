<header>
    <div class = "logo">
    <h1 class = 'logo-text'>FoodInsider</h1>
         
    </div>
    <ul class = "navbar">
        <li><a href = "#">Home</a></li>
        <li><a href = "#">Services</a></li>
        <li><a href = "#">About</a></li>
       <!--- <li><a href = "#">Sign Up</a></li>
        <li><a href = "#">Log in</a></li> --->
        <li>
            <a href = "#"><i class="far fa-user"></i>User</a>
            <ul>
                <li><a href = "#">Profile</a></li>
                <li><a href = "#" class = logout_bttn  >Logout</a></li>
                
            </ul>
        </li>       
    </ul>
</header>