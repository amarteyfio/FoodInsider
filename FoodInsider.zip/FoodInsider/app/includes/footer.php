<div class = "footer">
    <div class = "footer-content">
     <div class = "footer-section about">
         <h1>FoodInsider</h1>
         <p>FDay is a free Journal/Blogging website where users can feel free to express their thoughts on food recipes or food recommendations for University students. This can include diet palns that fit into the hectic day to day schedule of Uni students</p>
     </div>

     <div class = "footer-section links">
        <h2>Quick Links</h2> 
        <ul>
                <a href = '#' class="test"><li>Cookies</li></a>
                <a href = '#'><li>Copyright</li></a>
                <a href = '#'><li>Accesibility</li></a>
                <a href = '#'><li>User Agreements</li></a>
        </ul>
     </div>

     <div class = "footer-section contact">
     <h3>Want to Contact Us</h3>
    <form action = 'index.html' method="post">
         <input type="email" name="email" class="input-t" placeholder="Enter your Email Address">
         <br>
         <br>
         <textarea name="message" class="input-t" placeholder="Enter your Message"></textarea>
         <br>
         <button type="submit" name="submitbtn">Submit</button>
     </form>
     </div>
    </div>
    <div class = 'footer-bottom'>
        <p>www.fday.com|Designed by Group 3| All rights reserved</p>

    </div>
</div>